﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace StitchingImages
{
    public partial class MainForm : Form
    {
        List<PictureBox> ImgBoxList = new List<PictureBox>();
        RegionSelectForm rsform;
        StitchForm sform;
        List<Bitmap> ImgList = new List<Bitmap>();
        int R, C;
        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnRC_Click(object sender, EventArgs e)
        {
            R = int.Parse(TbxRC.Text.Split(',')[0]);
            C = int.Parse(TbxRC.Text.Split(',')[1]);
            Container.Controls.Clear();
            ImgBoxList.Clear();
            for (int i = 0; i < R * C; i++)
            {
                PictureBox ShowImgBox = new PictureBox();
                ShowImgBox.Margin = new Padding(3, 3, 3, 3);
                ShowImgBox.BorderStyle = BorderStyle.FixedSingle;
                ShowImgBox.Size = new Size(Container.Width / C - 6, Container.Height / R - 6);
                ShowImgBox.BackgroundImageLayout = ImageLayout.Zoom;
                ShowImgBox.SizeMode = PictureBoxSizeMode.StretchImage;
                ImgBoxList.Add(ShowImgBox);
                Container.Controls.Add(ImgBoxList.Last());
            }
        }

        private void 选择文件夹ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fb = new FolderBrowserDialog()
            {
                Description = "请选择文件夹",
            };
            if (fb.ShowDialog() == DialogResult.OK)
            {
                progressBar1.Maximum = R * C;
                DirectoryInfo TheFolder = new DirectoryInfo(fb.SelectedPath);
                int index = 0;
                foreach (FileInfo NextFile in TheFolder.GetFiles())
                {
                    progressBar1.Value++;
                    ImgList.Add(new Bitmap(NextFile.FullName));
                    ImgBoxList[index++].Image = ImgList.Last();
                }
            }
        }

        private void 拼接ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rsform = new RegionSelectForm(ImgList, R, C);
            rsform.ShowDialog();
            拼接ToolStripMenuItem1_Click(null, null);
        }

        private void 拼接ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            sform = new StitchForm(ImgList, R, C, rsform.Rscrtg, rsform.Mrtg, rsform.indexs);
            sform.ShowDialog();

            ResultForm result = new ResultForm(ImgList, R, C,
                rsform.Rscrtg, rsform.Mrtg, rsform.indexs,
                sform.TbxSamePoint_Rol.Text);
            result.Show();
        }

        private void 查看拼接图像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResultForm result = new ResultForm(ImgList, R, C,
               rsform.Rscrtg, rsform.Mrtg, rsform.indexs,
               sform.TbxSamePoint_Rol.Text);
            result.Show();
        }

        private void 自动拼接ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<int> indexs = new List<int>();
            for (int i = 0; i < R; i++)
                if (i % 2 == 0)
                    for (int j = 0; j < C; j++)
                        indexs.Add(i * C + j);
                else
                    for (int j = 0; j < C; j++)
                        indexs.Add(i * C + C - 1 - j);

            Rectangle r11 = new Rectangle(3588, 291, 75, 75);
            Rectangle r21 = new Rectangle(20, 3576, 75, 75);
            Rectangle r31 = new Rectangle(16, 27, 75, 75);
            Rectangle r12 = new Rectangle(59, 302, 50, 50);
            Rectangle r22 = new Rectangle(28, 46, 50, 50);
            Rectangle r32 = new Rectangle(3572, 45, 50, 50);

            List<Rectangle> rtg1 = new List<Rectangle>();
            List<Rectangle> rtg2 = new List<Rectangle>();

            for (int i = 1; i < R * C; i++)
            {
                var checkNum = indexs[i];
                if (checkNum % C == 0)
                {
                    rtg1.Add(r31);
                    rtg2.Add(r32);
                }
                else
                {
                    if (checkNum == i)
                    {
                        rtg1.Add(r11);
                        rtg2.Add(r12);
                    }
                    else
                    {
                        rtg1.Add(r21);
                        rtg2.Add(r22);
                    }
                }
            }

            sform = new StitchForm(ImgList, R, C, rtg1, rtg2, indexs);
            sform.ShowDialog();

            ResultForm result = new ResultForm(ImgList, R, C,
                rtg1, rtg2, indexs, sform.TbxSamePoint_Rol.Text);
            result.Show();


        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            BtnRC_Click(null, null);
        }
    }
}
