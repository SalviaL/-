﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace StitchingImages
{
    public partial class ResultForm : Form
    {
        int R, C;
        List<Bitmap> bitmap = new List<Bitmap>();
        List<Rectangle> Rscrtg = new List<Rectangle>();
        List<Rectangle> Mrtg = new List<Rectangle>();
        List<int> indexs = new List<int>();
        List<Point> SamePoint = new List<Point>();
        List<Point> ConnPoint = new List<Point>();

        Bitmap getImg(int index)
        {
            return bitmap[indexs[index]];
        }

        public ResultForm(List<Bitmap> bitmap, int R, int C,
            List<Rectangle> rscrtg, List<Rectangle> mrtg, List<int> indexs, string SamePointInfo)
        {
            InitializeComponent();
            this.R = R;
            this.C = C;
            this.bitmap = bitmap;
            this.Rscrtg = rscrtg;
            this.Mrtg = mrtg;
            this.indexs = indexs;

            foreach (var s in SamePointInfo.Split('\n'))
                if (s != "" && s != null)
                {
                    SamePoint.Add(new Point(int.Parse(s.Split(',')[0]),
                                            int.Parse(s.Split(',')[1])));
                }
        }

        private void 另存为tiffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv=new SaveFileDialog()
            {
                Title = "请选择保存路径",
                FileName = "StitchMap.tiff",
            };
            if (sv.ShowDialog() == DialogResult.OK)
                ImgBox.Image.Save(sv.FileName, System.Drawing.Imaging.ImageFormat.Tiff);
        }

        private void ResultForm_Load(object sender, EventArgs e)
        {
            ConnPoint.Add(new Point(0, 0));
            for (int i = 0; i < SamePoint.Count; i++)
            {
                int x = Rscrtg[i].X - Mrtg[i].X + SamePoint[i].X;
                int y = Rscrtg[i].Y - Mrtg[i].Y + SamePoint[i].Y;
                ConnPoint.Add(new Point(ConnPoint.Last().X + x,
                                        ConnPoint.Last().Y + y));

            }

            int H = ConnPoint.Max(p => p.Y) + bitmap[0].Height;
            int W = ConnPoint.Max(p => p.X) + bitmap[0].Width;

            Bitmap StMap = new Bitmap(W, H);

            Graphics G = Graphics.FromImage(StMap);
            for (int i = 0; i < ConnPoint.Count; i++)
                G.DrawImage(getImg(i), ConnPoint[i]);

            ImgBox.Image = StMap;
        }
    }
}
