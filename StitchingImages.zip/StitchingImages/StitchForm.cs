﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StitchingImages
{
    public partial class StitchForm : Form
    {
        int R, C;
        int ImgIndex = 0;
        List<Bitmap> bitmap = new List<Bitmap>();
        List<Rectangle> Rscrtg = new List<Rectangle>();
        List<Rectangle> Mrtg = new List<Rectangle>();
        List<int> indexs = new List<int>();
        List<PictureBox> ImgBoxList = new List<PictureBox>();

        Bitmap getImg(int index)
        {
            return bitmap[indexs[index]];
        }

        void UpLayoutColor()
        {
            foreach (var b in ImgBoxList)
                b.BackColor = Color.Blue;
            ImgBoxList[indexs[ImgIndex]].BackColor = Color.Red;
            ImgBoxList[indexs[ImgIndex - 1]].BackColor = Color.Green;
        }

        public StitchForm(List<Bitmap> bitmap, int R, int C,
            List<Rectangle> rscrtg, List<Rectangle> mrtg, List<int> indexs)
        {
            InitializeComponent();
            this.R = R;
            this.C = C;
            this.bitmap = bitmap;
            this.Rscrtg = rscrtg;
            this.Mrtg = mrtg;
            this.indexs = indexs;
        }

        private void BtnSt_Click(object sender, EventArgs e)
        {
            progressBar1.Maximum = R * C - 1;
            for (int i = 0; i < R * C - 1; i++)
            {
                progressBar1.Value++;
                ClsImg.GetSamePoint(getImg(i), getImg(i + 1), Rscrtg[i], Mrtg[i],
                    ref panel1, ref panel2,ref TbxSamePoint_Rol);

            }
            MessageBox.Show("图像匹配完成！");
            this.Close();
        }

        private void StitchForm_Load(object sender, EventArgs e)
        {
            //TbxSamePoint_Rol.Text = "";
            //bitmap = new List<Bitmap>();
            //Rscrtg = new List<Rectangle>();
            //Mrtg = new List<Rectangle>();
            //indexs = new List<int>();
            //ImgBoxList = new List<PictureBox>();
        }
    }
}
