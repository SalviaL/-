﻿using System.Drawing;
using System.Collections;
using System.Collections.Generic;

namespace StitchingImages
{
    partial class RegionSelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PbxImg1 = new System.Windows.Forms.PictureBox();
            this.PbxImg2 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TbxPointRsc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TbxArsc = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TbxAM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TbxPintM = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnNext = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            this.ImgLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbxImg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxImg2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.PbxImg1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(282, 467);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.PbxImg2);
            this.panel2.Location = new System.Drawing.Point(300, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(282, 467);
            this.panel2.TabIndex = 1;
            // 
            // PbxImg1
            // 
            this.PbxImg1.Location = new System.Drawing.Point(0, 0);
            this.PbxImg1.Name = "PbxImg1";
            this.PbxImg1.Size = new System.Drawing.Size(100, 50);
            this.PbxImg1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PbxImg1.TabIndex = 0;
            this.PbxImg1.TabStop = false;
            this.PbxImg1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PbxImg1_MouseClick);
            this.PbxImg1.MouseEnter += new System.EventHandler(this.PbxImg1_MouseEnter);
            this.PbxImg1.MouseLeave += new System.EventHandler(this.PbxImg1_MouseLeave);
            // 
            // PbxImg2
            // 
            this.PbxImg2.Location = new System.Drawing.Point(0, 0);
            this.PbxImg2.Name = "PbxImg2";
            this.PbxImg2.Size = new System.Drawing.Size(100, 50);
            this.PbxImg2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.PbxImg2.TabIndex = 1;
            this.PbxImg2.TabStop = false;
            this.PbxImg2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PbxImg2_MouseClick);
            this.PbxImg2.MouseEnter += new System.EventHandler(this.PbxImg2_MouseEnter);
            this.PbxImg2.MouseLeave += new System.EventHandler(this.PbxImg2_MouseLeave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TbxArsc);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TbxPointRsc);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(588, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(151, 102);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "搜索区域";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "左上角相对图像坐标";
            // 
            // TbxPointRsc
            // 
            this.TbxPointRsc.Location = new System.Drawing.Point(8, 32);
            this.TbxPointRsc.Name = "TbxPointRsc";
            this.TbxPointRsc.Size = new System.Drawing.Size(100, 21);
            this.TbxPointRsc.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "边长（像素，默认75）";
            // 
            // TbxArsc
            // 
            this.TbxArsc.Location = new System.Drawing.Point(8, 71);
            this.TbxArsc.Name = "TbxArsc";
            this.TbxArsc.Size = new System.Drawing.Size(100, 21);
            this.TbxArsc.TabIndex = 3;
            this.TbxArsc.Text = "75";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TbxAM);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.TbxPintM);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(588, 120);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(151, 102);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "模板区域";
            // 
            // TbxAM
            // 
            this.TbxAM.Location = new System.Drawing.Point(8, 71);
            this.TbxAM.Name = "TbxAM";
            this.TbxAM.Size = new System.Drawing.Size(100, 21);
            this.TbxAM.TabIndex = 3;
            this.TbxAM.Text = "50";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "边长（像素，默认50）";
            // 
            // TbxPintM
            // 
            this.TbxPintM.Location = new System.Drawing.Point(8, 32);
            this.TbxPintM.Name = "TbxPintM";
            this.TbxPintM.Size = new System.Drawing.Size(100, 21);
            this.TbxPintM.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "左上角相对图像坐标";
            // 
            // BtnNext
            // 
            this.BtnNext.Location = new System.Drawing.Point(588, 228);
            this.BtnNext.Name = "BtnNext";
            this.BtnNext.Size = new System.Drawing.Size(151, 65);
            this.BtnNext.TabIndex = 5;
            this.BtnNext.Text = "确认，下一组图像";
            this.BtnNext.UseVisualStyleBackColor = true;
            this.BtnNext.Click += new System.EventHandler(this.BtnNext_Click);
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(588, 299);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(151, 23);
            this.BtnBack.TabIndex = 6;
            this.BtnBack.Text = "返回上一组";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // ImgLayoutPanel
            // 
            this.ImgLayoutPanel.Location = new System.Drawing.Point(588, 328);
            this.ImgLayoutPanel.Name = "ImgLayoutPanel";
            this.ImgLayoutPanel.Size = new System.Drawing.Size(150, 150);
            this.ImgLayoutPanel.TabIndex = 7;
            // 
            // RegionSelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 491);
            this.Controls.Add(this.ImgLayoutPanel);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.BtnNext);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "RegionSelectForm";
            this.Text = "RegionSelectForm";
            this.Load += new System.EventHandler(this.RegionSelectForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbxImg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxImg2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        public List<Point> RscPoint = new List<Point>();
        public List<Point> MPoint = new List<Point>();
        public List<Rectangle> Rscrtg = new List<Rectangle>();
        public List<Rectangle> Mrtg = new List<Rectangle>();
        public List<int> indexs = new List<int>();
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox PbxImg1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox PbxImg2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TbxArsc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TbxPointRsc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TbxAM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TbxPintM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnNext;
        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.FlowLayoutPanel ImgLayoutPanel;
    }
}