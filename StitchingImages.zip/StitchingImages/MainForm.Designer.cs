﻿namespace StitchingImages
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择文件夹ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编辑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.拼接ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.拼接ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.查看拼接图像ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.度002度0001度重叠自动拼接ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnRC = new System.Windows.Forms.Button();
            this.TbxRC = new System.Windows.Forms.TextBox();
            this.Container = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.编辑ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(744, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.选择文件夹ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // 选择文件夹ToolStripMenuItem
            // 
            this.选择文件夹ToolStripMenuItem.Name = "选择文件夹ToolStripMenuItem";
            this.选择文件夹ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.选择文件夹ToolStripMenuItem.Text = "选择文件夹";
            this.选择文件夹ToolStripMenuItem.Click += new System.EventHandler(this.选择文件夹ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            // 
            // 编辑ToolStripMenuItem
            // 
            this.编辑ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.拼接ToolStripMenuItem,
            this.拼接ToolStripMenuItem1,
            this.查看拼接图像ToolStripMenuItem,
            this.度002度0001度重叠自动拼接ToolStripMenuItem});
            this.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem";
            this.编辑ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.编辑ToolStripMenuItem.Text = "编辑";
            // 
            // 拼接ToolStripMenuItem
            // 
            this.拼接ToolStripMenuItem.Name = "拼接ToolStripMenuItem";
            this.拼接ToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.拼接ToolStripMenuItem.Text = "选择模板区域";
            this.拼接ToolStripMenuItem.Click += new System.EventHandler(this.拼接ToolStripMenuItem_Click);
            // 
            // 拼接ToolStripMenuItem1
            // 
            this.拼接ToolStripMenuItem1.Name = "拼接ToolStripMenuItem1";
            this.拼接ToolStripMenuItem1.Size = new System.Drawing.Size(280, 22);
            this.拼接ToolStripMenuItem1.Text = "拼接";
            this.拼接ToolStripMenuItem1.Click += new System.EventHandler(this.拼接ToolStripMenuItem1_Click);
            // 
            // 查看拼接图像ToolStripMenuItem
            // 
            this.查看拼接图像ToolStripMenuItem.Name = "查看拼接图像ToolStripMenuItem";
            this.查看拼接图像ToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.查看拼接图像ToolStripMenuItem.Text = "查看拼接图像";
            this.查看拼接图像ToolStripMenuItem.Click += new System.EventHandler(this.查看拼接图像ToolStripMenuItem_Click);
            // 
            // 度002度0001度重叠自动拼接ToolStripMenuItem
            // 
            this.度002度0001度重叠自动拼接ToolStripMenuItem.Name = "度002度0001度重叠自动拼接ToolStripMenuItem";
            this.度002度0001度重叠自动拼接ToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.度002度0001度重叠自动拼接ToolStripMenuItem.Text = "0.02度*0.02度，0.001度重叠自动拼接";
            this.度002度0001度重叠自动拼接ToolStripMenuItem.Click += new System.EventHandler(this.自动拼接ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnRC);
            this.groupBox1.Controls.Add(this.TbxRC);
            this.groupBox1.Location = new System.Drawing.Point(608, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(124, 87);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "行列数（行,列,）";
            // 
            // BtnRC
            // 
            this.BtnRC.Location = new System.Drawing.Point(23, 53);
            this.BtnRC.Name = "BtnRC";
            this.BtnRC.Size = new System.Drawing.Size(75, 23);
            this.BtnRC.TabIndex = 1;
            this.BtnRC.Text = "确认";
            this.BtnRC.UseVisualStyleBackColor = true;
            this.BtnRC.Click += new System.EventHandler(this.BtnRC_Click);
            // 
            // TbxRC
            // 
            this.TbxRC.Location = new System.Drawing.Point(31, 26);
            this.TbxRC.Name = "TbxRC";
            this.TbxRC.Size = new System.Drawing.Size(59, 21);
            this.TbxRC.TabIndex = 0;
            this.TbxRC.Text = "2,2";
            // 
            // Container
            // 
            this.Container.Location = new System.Drawing.Point(12, 40);
            this.Container.Name = "Container";
            this.Container.Size = new System.Drawing.Size(590, 465);
            this.Container.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(608, 133);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(136, 372);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Location = new System.Drawing.Point(0, 507);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(744, 10);
            this.progressBar1.TabIndex = 4;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 517);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Container);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "图像拼接";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 选择文件夹ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编辑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 拼接ToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnRC;
        private System.Windows.Forms.TextBox TbxRC;
        private System.Windows.Forms.FlowLayoutPanel Container;
        private System.Windows.Forms.ToolStripMenuItem 拼接ToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem 查看拼接图像ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 度002度0001度重叠自动拼接ToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}

