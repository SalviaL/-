﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StitchingImages
{
    public partial class RegionSelectForm : Form
    {
        int ImgIndex = 0;
        List<Bitmap> bitmap;
        List<PictureBox> ImgBoxList = new List<PictureBox>();
        Point rscpoint, mpoint;
        int R, C;
        bool me1, me2;
        Panel pl1 = new Panel()
        {
            BackColor = Color.Transparent,
            BorderStyle = BorderStyle.Fixed3D,
            Location = new Point(0, 0),
            Size = new Size(75, 75),
        };

        Panel pl2 = new Panel()
        {
            BackColor = Color.Transparent,
            BorderStyle = BorderStyle.Fixed3D,
            Size = new Size(50, 50),
            Location = new Point(0, 0),
        };

        void UpLayoutColor()
        {
            foreach (var b in ImgBoxList)
                b.BackColor = Color.Blue;
            ImgBoxList[indexs[ImgIndex]].BackColor = Color.Red;
            ImgBoxList[indexs[ImgIndex - 1]].BackColor = Color.Green;
        }
        void UpPoints(Point rscp, Point mp)
        {
            int a1 = int.Parse(TbxArsc.Text);
            int a2 = int.Parse(TbxAM.Text);
            if (RscPoint.Count >= ImgIndex)
            {
                RscPoint[ImgIndex - 1] = rscp;
                MPoint[ImgIndex - 1] = mp;
                Rscrtg[ImgIndex - 1] =
                    new Rectangle((rscp.X - a1 / 2) >= 0 ? (rscp.X - a1 / 2) : 0,
                                  (rscp.Y - a1 / 2) >= 0 ? (rscp.Y - a1 / 2) : 0,
                                  a1, a1);
                Mrtg[ImgIndex - 1] = new Rectangle((mp.X - a2 / 2) >= 0 ? (mp.X - a2 / 2) : 0,
                                  (mp.Y - a2 / 2) >= 0 ? (mp.Y - a2 / 2) : 0,
                                  a2, a2);
            }
            else
            {
                RscPoint.Add(rscp);
                MPoint.Add(mp);
                Rscrtg.Add(new Rectangle((rscp.X - a1 / 2) >= 0 ? (rscp.X - a1 / 2) : 0,
                                  (rscp.Y - a1 / 2) >= 0 ? (rscp.Y - a1 / 2) : 0,
                                  a1, a1));
                Mrtg.Add(new Rectangle((mp.X - a2 / 2) >= 0 ? (mp.X - a2 / 2) : 0,
                                  (mp.Y - a2 / 2) >= 0 ? (mp.Y - a2 / 2) : 0,
                                  a2, a2));
            }
        }

        Bitmap getImg(int index)
        {
            return bitmap[indexs[index]];
        }
        public RegionSelectForm(List<Bitmap> bitmap, int R, int C)
        {
            InitializeComponent();
            this.bitmap = bitmap;
            this.R = R;
            this.C = C;
        }

        private void PbxImg1_MouseLeave(object sender, EventArgs e)
        {
            me1 = false;
        }
        private void PbxImg2_MouseEnter(object sender, EventArgs e)
        {
            me2 = true;
        }
        private void PbxImg2_MouseLeave(object sender, EventArgs e)
        {
            me2 = false;
        }
        private void PbxImg1_MouseClick(object sender, MouseEventArgs e)
        {
            if (me1)
            {
                TbxPointRsc.Text = e.Location.ToString();
                rscpoint = e.Location;
                int a = int.Parse(TbxArsc.Text);
                pl1.Location = new Point((e.X - a / 2) >= 0 ? e.X - a / 2 : 0,
                                         (e.Y - a / 2) >= 0 ? e.Y - a / 2 : 0);
                pl1.Size = new Size(a, a);
            }
        }
        private void PbxImg2_MouseClick(object sender, MouseEventArgs e)
        {
            if (me2)
            {
                TbxPintM.Text = e.Location.ToString();
                mpoint = e.Location;
                int a = int.Parse(TbxAM.Text);
                pl2.Location = new Point((e.X - a / 2) >= 0 ? e.X - a / 2 : 0,
                                         (e.Y - a / 2) >= 0 ? e.Y - a / 2 : 0);
                pl2.Size = new Size(a, a);
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (ImgIndex > 1)
            {
                ImgIndex -= 2;
                PbxImg1.Image = getImg(ImgIndex++);
                PbxImg2.Image = getImg(ImgIndex);
                UpLayoutColor();
            }
        }
        private void BtnNext_Click(object sender, EventArgs e)
        {
            UpPoints(rscpoint, mpoint);
            if (ImgIndex < R * C - 1)
            {
                PbxImg1.Image = getImg(ImgIndex++);
                PbxImg2.Image = getImg(ImgIndex);
                UpLayoutColor();
            }
            else
            {
                MessageBox.Show("模板选择完毕！");
                this.Close();
            }
        }
        private void PbxImg1_MouseEnter(object sender, EventArgs e)
        {
            me1 = true;
        }
        private void RegionSelectForm_Load(object sender, EventArgs e)
        {
            RscPoint = new List<Point>();
            MPoint = new List<Point>();
            Rscrtg = new List<Rectangle>();
            Mrtg = new List<Rectangle>();
            indexs = new List<int>();

            for (int i = 0; i < R; i++)
                if (i % 2 == 0)
                    for (int j = 0; j < C; j++)
                        indexs.Add(i * C + j);
                else
                    for (int j = 0; j < C; j++)
                        indexs.Add(i * C + C - 1 - j);

            PbxImg1.Image = getImg(ImgIndex++);
            PbxImg2.Image = getImg(ImgIndex);
            int H = ImgLayoutPanel.Height / R;
            int W = ImgLayoutPanel.Height / C;
            for (int i = 0; i < R * C; i++)
            {
                PictureBox ShowImgBox = new PictureBox();
                ShowImgBox.Margin = new Padding(0, 0, 0, 0);
                ShowImgBox.BorderStyle = BorderStyle.FixedSingle;
                ShowImgBox.Size = new Size(W, H);
                ShowImgBox.BackgroundImageLayout = ImageLayout.Zoom;
                ShowImgBox.SizeMode = PictureBoxSizeMode.StretchImage;
                ImgBoxList.Add(ShowImgBox);
                ImgLayoutPanel.Controls.Add(ImgBoxList.Last());
            }

            PbxImg1.Controls.Add(pl1);
            PbxImg2.Controls.Add(pl2);

            UpLayoutColor();


        }
    }
}
