﻿namespace StitchingImages
{
    partial class StitchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BtnSt = new System.Windows.Forms.Button();
            this.TbxSamePoint_Rol = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(75, 75);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(13, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(50, 50);
            this.panel2.TabIndex = 0;
            // 
            // BtnSt
            // 
            this.BtnSt.Location = new System.Drawing.Point(268, 64);
            this.BtnSt.Name = "BtnSt";
            this.BtnSt.Size = new System.Drawing.Size(75, 23);
            this.BtnSt.TabIndex = 9;
            this.BtnSt.Text = "拼接";
            this.BtnSt.UseVisualStyleBackColor = true;
            this.BtnSt.Click += new System.EventHandler(this.BtnSt_Click);
            // 
            // TbxSamePoint_Rol
            // 
            this.TbxSamePoint_Rol.Location = new System.Drawing.Point(105, 25);
            this.TbxSamePoint_Rol.Multiline = true;
            this.TbxSamePoint_Rol.Name = "TbxSamePoint_Rol";
            this.TbxSamePoint_Rol.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxSamePoint_Rol.Size = new System.Drawing.Size(157, 62);
            this.TbxSamePoint_Rol.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(103, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "同名点和相关系数";
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Location = new System.Drawing.Point(0, 117);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(355, 10);
            this.progressBar1.TabIndex = 16;
            // 
            // StitchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 127);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TbxSamePoint_Rol);
            this.Controls.Add(this.BtnSt);
            this.Controls.Add(this.panel1);
            this.Name = "StitchForm";
            this.Text = "StitchForm";
            this.Load += new System.EventHandler(this.StitchForm_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
       
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button BtnSt;
        public System.Windows.Forms.TextBox TbxSamePoint_Rol;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}