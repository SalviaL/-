﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace StitchingImages
{
    /// <summary>
    /// 图像拼接静态方法库
    /// </summary>
    public class ClsImg
    {
        /// <summary>
        /// 图像转矩阵
        /// </summary>
        /// <param name="bitmap">图像</param>
        /// <returns>三维矩阵（分别代表RGB）</returns>
        public static byte[,,] Bitmap2Byte(Bitmap bitmap)
        {
            byte[,,] Matrix = new byte[bitmap.Height, bitmap.Width, 3];
            for (int i = 0; i < bitmap.Height; i++)
                for (int j = 0; j < bitmap.Width; j++)
                {
                    Matrix[i, j, 0] = bitmap.GetPixel(i, j).R;
                    Matrix[i, j, 1] = bitmap.GetPixel(i, j).G;
                    Matrix[i, j, 2] = bitmap.GetPixel(i, j).B;
                }
            return Matrix;
        }
        /// <summary>
        /// 矩阵转图像
        /// </summary>
        /// <param name="bytes">三维矩阵（分别表示RGB）</param>
        /// <returns>图像</returns>
        public static Bitmap Bytes2Bitmap(byte[,,] bytes)
        {
            Bitmap bitmap = new Bitmap(bytes.GetLength(0), bytes.GetLength(1),
                                       PixelFormat.Format32bppArgb);
            for (int i = 0; i < bitmap.Height; i++)
                for (int j = 0; j < bitmap.Width; j++)
                    bitmap.SetPixel(i, j, Color.FromArgb(bytes[i, j, 0], bytes[i, j, 1], bytes[i, j, 2]));
            return bitmap;
        }
        /// <summary>
        /// 利用像素灰度值差值的方差查找同名点
        /// </summary>
        /// <param name="img1">参考图像</param>
        /// <param name="img2">拼接图像</param>
        /// <param name="rtg1">参考图像搜索区域</param>
        /// <param name="rtg2">拼接图像模板区域</param>
        /// <returns>同名点（相对于参考图像坐标）</returns>
        public static Point GetSamePoint(Bitmap img1, Bitmap img2, Rectangle rtg1, Rectangle rtg2,
            ref Panel pl1, ref Panel pl2, ref TextBox tbxsamepointrol)
        {
            var SearchImg = img1.Clone(rtg1, 0);
            pl1.BackgroundImage = SearchImg;
            pl2.BackgroundImage = img2.Clone(rtg2, 0);
            pl2.Location = new Point(0, 0);
            var ModelRegion = Bitmap2Byte(img2.Clone(rtg2, 0));
            double rol0 = 0;
            Point SamePoint = new Point(0, 0);

            for (int i = 0; i < SearchImg.Height - ModelRegion.GetLength(0); i++)
                for (int j = 0; j < SearchImg.Width - ModelRegion.GetLength(1); j++)
                {
                    pl2.Location = new Point(i, j);
                    Rectangle Cmprtg = new Rectangle(i, j, rtg2.Width, rtg2.Height);
                    var CmpRegion = Bitmap2Byte(SearchImg.Clone(Cmprtg, 0));
                    double rol = ComputationVariance(ModelRegion, CmpRegion);
                    if (rol > rol0)
                    {
                        SamePoint = new Point(i, j);
                        rol0 = rol;
                    }
                }
            tbxsamepointrol.AppendText(SamePoint.X.ToString().PadLeft(2,'0') + ',' +
                                       SamePoint.Y.ToString().PadLeft(2,'0') + ',' +
                                       rol0.ToString("0.0000") + "\r\n");
            tbxsamepointrol.ScrollToCaret();
            pl2.Location = SamePoint;
            return SamePoint;

        }
        /// <summary>
        /// 计算图像灰度值差值方差均根值
        /// </summary>
        /// <param name="modelRegion"></param>
        /// <param name="cmpRegion"></param>
        /// <returns></returns>
        private static double ComputationVariance(byte[,,] modelRegion, byte[,,] cmpRegion)
        {
            double[,] matrix1 = new double[modelRegion.GetLength(0), modelRegion.GetLength(1)];
            double[,] matrix2 = new double[modelRegion.GetLength(0), modelRegion.GetLength(1)];
            double mean1 = 0;
            double mean2 = 0;
            int PixCount = modelRegion.GetLength(0) * modelRegion.GetLength(1);
            for (int i = 0; i < modelRegion.GetLength(0) - 1; i++)
                for (int j = 0; j < modelRegion.GetLength(1) - 1; j++)
                {
                    matrix1[i, j] = (modelRegion[i, j, 0] + modelRegion[i, j, 1] + modelRegion[i, j, 2]) / 3;
                    matrix2[i, j] = (cmpRegion[i, j, 0] + cmpRegion[i, j, 1] + cmpRegion[i, j, 2]) / 3;
                    mean1 += matrix1[i, j];
                    mean2 += matrix2[i, j];
                }
            mean1 /= PixCount;
            mean2 /= PixCount;

            double C12 = 0;
            double C11 = 0;
            double C22 = 0;
            for (int i = 0; i < modelRegion.GetLength(0) - 1; i++)
                for (int j = 0; j < modelRegion.GetLength(1) - 1; j++)
                {
                    C12 += (matrix1[i, j] - mean1) * (matrix2[i, j] - mean2);
                    C11 += (matrix1[i, j] - mean1) * (matrix1[i, j] - mean1);
                    C22 += (matrix2[i, j] - mean2) * (matrix2[i, j] - mean2);
                }
            return Math.Abs(C12 / Math.Sqrt(C11 * C22));
        }
    }
}
